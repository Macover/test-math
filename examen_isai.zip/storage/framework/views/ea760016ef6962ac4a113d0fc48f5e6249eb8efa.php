<?php $__env->startSection('titulo'); ?>
    <title>VISTA ADMIN</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo-pagina'); ?>
    <h1 class="h3 mb-4 text-danger-800">TOP mejores 5</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <div class="col-md-12">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>ID del usuario</th>
                            <th>Nombre del usuario</th>
                            <th>edad</th>
                            <th>genero</th>
                            <th>puntaje</th>
                            <th>Detalles</th>
                        </tr>
                        </thead>
                        <tfoot>
                        <tr>
                            <th>#</th>
                            <th>ID del usuario</th>
                            <th>Nombre del usuario</th>
                            <th>edad</th>
                            <th>genero</th>
                            <th>puntaje</th>
                            <th>Detalles</th>
                        </tr>
                        </tfoot>
                        <tbody>
                            <tr>
                                <th>1</th>
                                <th><?php echo e($id1); ?></th>
                                <th><?php echo e($nombre1); ?></th>
                                <th><?php echo e($edad1); ?></th>
                                <th><?php echo e($genero1); ?></th>
                                <th><?php echo e($puntaje1); ?></th>
                                <th><a href="<?php echo e(route('detalles.usuario',$id1)); ?>" class="btn btn-block btn-warning">Detalles</a></th>
                            </tr>
                        </tbody>
                        <tbody>
                        <tr>
                            <th>2</th>
                            <th><?php echo e($id2); ?></th>
                            <th><?php echo e($nombre2); ?></th>
                            <th><?php echo e($edad2); ?></th>
                            <th><?php echo e($genero2); ?></th>
                            <th><?php echo e($puntaje2); ?></th>
                            <th><a href="<?php echo e(route('detalles.usuario',$id2)); ?>" class="btn btn-block btn-warning">Detalles</a></th>
                        </tr>
                        </tbody>
                        <tbody>
                        <tr>
                            <th>3</th>
                            <th><?php echo e($id3); ?></th>
                            <th><?php echo e($nombre3); ?></th>
                            <th><?php echo e($edad3); ?></th>
                            <th><?php echo e($genero3); ?></th>
                            <th><?php echo e($puntaje3); ?></th>
                            <th><a href="<?php echo e(route('detalles.usuario',$id3)); ?>" class="btn btn-block btn-warning">Detalles</a></th>
                        </tr>
                        </tbody>
                        <tbody>
                        <tr>
                            <th>4</th>
                            <th><?php echo e($id4); ?></th>
                            <th><?php echo e($nombre4); ?></th>
                            <th><?php echo e($edad4); ?></th>
                            <th><?php echo e($genero4); ?></th>
                            <th><?php echo e($puntaje4); ?></th>
                            <th><a href="<?php echo e(route('detalles.usuario',$id4)); ?>" class="btn btn-block btn-warning">Detalles</a></th>
                        </tr>
                        </tbody>
                        <tbody>
                        <tr>
                            <th>5</th>
                            <th><?php echo e($id5); ?></th>
                            <th><?php echo e($nombre5); ?></th>
                            <th><?php echo e($edad5); ?></th>
                            <th><?php echo e($genero5); ?></th>
                            <th><?php echo e($puntaje5); ?></th>
                            <th><a href="<?php echo e(route('detalles.usuario',$id5)); ?>" class="btn btn-block btn-warning">Detalles</a></th>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Page level plugins -->
    <script src="/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="/vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout_admin.mainAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Macov\Desktop\nuevo_repo\examen_isai\resources\views/topMejores.blade.php ENDPATH**/ ?>