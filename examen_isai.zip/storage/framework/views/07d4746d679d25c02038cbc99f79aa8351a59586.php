<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title></title>
</head>
<body>

<table>
    <thead>
    <tr>
        <th>ID_Usuario</th>
        <th>Nombre del Usuario</th>
        <th>Correo</th>
        <th>Genero</th>
        <th>Edad</th>
        <th>Puntaje</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <th><?php echo e($resUsuario->id_usuario); ?></th>
        <th><?php echo e($usuario->nombre_usuario); ?></th>
        <th><?php echo e($usuario->correo); ?></th>
        <th><?php echo e($resUsuario->genero); ?></th>
        <th><?php echo e($resUsuario->edad); ?></th>
        <th><?php echo e($resUsuario->puntaje); ?></th>

    </tr>
    </tbody>
</table>

</body>
</html>
<?php /**PATH C:\Users\Macov\Desktop\nuevo_repo\examen_isai\resources\views/pdf/tabla.blade.php ENDPATH**/ ?>