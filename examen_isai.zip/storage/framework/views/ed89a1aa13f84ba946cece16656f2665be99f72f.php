<?php $__env->startSection('titulo'); ?>
    <title>EXAMEN</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo-pagina'); ?>
    <h1 class="h3 mb-4 text-gray-800">CONTENIDO</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Macov\Desktop\master\examen_isai\resources\views/preguntasForm.blade.php ENDPATH**/ ?>
