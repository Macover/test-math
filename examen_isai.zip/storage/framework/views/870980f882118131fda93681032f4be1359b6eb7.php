<?php $__env->startSection('titulo'); ?>
    <title>VISTA ADMIN</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo-pagina'); ?>
    <h1 class="h3 mb-4 text-danger-800">Resultados</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <div class="col-md-12">
        <div class="card shadow mb-4">
                    <div class="card-header py-3">
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>ID del usuario</th>
                                    <th>genero</th>
                                    <th>edad</th>
                                    <th>puntaje</th>
                                    <th>Detalles</th>
                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                    <th>#</th>
                                    <th>ID del usuario</th>
                                    <th>genero</th>
                                    <th>edad</th>
                                    <th>puntaje</th>
                                    <th>Detalles</th>
                                </tr>
                                </tfoot>
                                <tbody>
                                <?php $__currentLoopData = $resultados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tablaResultados): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td id="idUsuario"><?php echo e($tablaResultados->id_usuario); ?></td>
                                        <td><?php echo e($tablaResultados->genero); ?></td>
                                        <td><?php echo e($tablaResultados->edad); ?></td>
                                        <td><?php echo e($tablaResultados->puntaje); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('detalles.usuario',$tablaResultados->id_usuario)); ?>" class="btn btn-block btn-warning">Detalles</a>
                                            <a href="<?php echo e(route('descargar.pdf',$tablaResultados->id_usuario)); ?>" class="btn btn-block btn-outline-secondary">DESCARGAR PDF</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Page level plugins -->
    <script src="/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="/vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script>

    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout_admin.mainAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Macov\Desktop\nuevo_repo\examen_isai\resources\views/tablaResultados.blade.php ENDPATH**/ ?>