<?php $__env->startSection('titulo'); ?>
    <title>VISTA ADMIN</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo-pagina'); ?>
    <h1 class="h3 mb-4 text-danger">Detalles usuario.</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout_admin.mainAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Macov\Desktop\nuevo_repo\examen_isai\resources\views/detallesUsuario.blade.php ENDPATH**/ ?>