<?php $__env->startSection('titulo'); ?>
    <title>Resultados usuario</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo-pagina'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

   <div class="container">

      <?php if(isset($correo)): ?>

           <div class="row justify-content-center">

               <div class="col-xl-10 col-lg-12 col-md-9">

                   <div class="card o-hidden border-0 shadow-lg my-5">
                       <div class="card-body p-0">
                           <!-- Nested Row within Card Body -->
                           <div class="row">
                               <div class="container text-center my-auto">
                                   <h1 class="mb-1">¡Felicitaciones <?php echo e($nombreUsuario); ?>! Usted ah completado el test de lógica matemática</h1>
                                   <h3 class="mb-5">
                                       <em>Sus respuestas han sido enviadas a: <?php echo e($correo); ?> </em>
                                   </h3>
                                   <h3 class="mb-5">
                                       <em class="text-warning">Obtuvó: <?php echo e($puntaje); ?> puntos de 5 preguntas </em>
                                   </h3>

                                   <a class="btn btn-outline-warning btn-xl js-scroll-trigger" href="<?php echo e(route('cerrar.sesion')); ?>">Cerrar Sesion</a>

                               </div>
                           </div>
                       </div>
                   </div>

               </div>

           </div>

          <?php endif; ?>

   </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Macov\Desktop\master\examen_isai\resources\views/resultado.blade.php ENDPATH**/ ?>