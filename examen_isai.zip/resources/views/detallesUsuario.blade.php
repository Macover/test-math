@extends('layout_admin.mainAdmin')

@section('titulo')
    <title>VISTA ADMIN</title>
@endsection

@section('css')

@endsection

@section('titulo-pagina')
    <h1 class="h3 mb-4 text-danger">Detalles usuario.</h1>
@endsection

@section('contenido')

@endsection

@section('js')

@endsection

